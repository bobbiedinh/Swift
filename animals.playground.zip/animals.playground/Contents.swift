import UIKit

class Animal {
    var name: String
    var health: Int
    
    init(name: String, health: Int = 100) {
        self.name = name
        self.health = health
    }
    func displayHealth() -> Int {
        return self.health
    }
}

class Cat: Animal {
    override init(name: String, health: Int = 150) {
        super.init(name: name, health: health)
    }
    func growl() {
        print("Rawr!")
    }
    func run() {
        self.health-=10
        print("Health: \(self.health)")
        print("Running")
    }
}

class Cheetah: Cat {
    init(name: String){
        super.init(name: name)
    }
    override func run(){
        if (self.health-50 >= 0){
            self.health-=50
            print("Health: \(self.health)")
            print("Running Fast")
        }
        else {
            print("Not enough HP")
        }
    }
    func sleep(){
        if self.health+50<=200{
            self.health+=50
        }
    }
}

class Lion: Cat{
    override init(name: String, health: Int = 200){
        super.init(name: name, health: health)
    }
    override func growl() {
        print("ROAR")
    }
}

var cheetah = Cheetah(name: "Rachelle")
cheetah.run()
cheetah.run()
cheetah.run()
cheetah.run()

var lion = Lion(name: "Bobbie")
lion.run()
lion.run()
lion.run()
lion.growl()
