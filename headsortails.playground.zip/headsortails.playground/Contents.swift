import UIKit

func tossCoin() -> String{
    print("Tossing a Coin!")
    let rand = arc4random_uniform(2)
    if rand==1{
        return "Heads"
    }
    else {
        return "Tails"
    }
}

func tossMultipleCoins(iterate: Int) -> Double {
    var heads = 0
    var tails = 0
    for _ in 0..<iterate{
        let result = tossCoin()
        if result == "Heads"{
            heads+=1
            print("Heads: \(heads)")
        }
        else {
            tails+=1
            print("Tails: \(tails)")
        }
    }
    return Double (heads)/Double (iterate)
}
print(tossMultipleCoins(iterate: 10))
