import UIKit

struct Point {
    var X: Double
    var Y: Double
    init(X: Double, Y: Double) {
        self.X = X
        self.Y = Y
    }
}

struct Line {
    var Start: Point
    var End: Point
    
    func length() -> Double {
        let length = (pow((self.Start.X - self.End.X), 2) + pow((self.Start.Y - self.End.Y), 2)).squareRoot()
        return length
    }
}

var pointOne = Point(X:2, Y:4)
var pointTwo = Point(X:3, Y:-6)
var pointThree = Point(X:7, Y:8)
var points: [Point] = [pointOne, pointTwo, pointThree]
var line:Double = Line(Start: pointOne, End: pointTwo).length()

struct Triangle {
    var Points: [Point]
    
    func area() -> Double {
        let pointOne = self.Points[0]
        let pointTwo = self.Points[1]
        let pointThree = self.Points[2]
        
        let area = 0.5*((pointOne.X * (pointTwo.Y - pointThree.Y)) + (pointTwo.X * (pointThree.Y - pointOne.Y)) + (pointThree.X * (pointOne.Y - pointTwo.Y)))
        return area
    }
}
var area: Double = Triangle(Points: points).area()
print(area)
