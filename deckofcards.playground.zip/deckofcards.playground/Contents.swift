import UIKit

struct Card {
    var color: String
    var roll: Int
    init (color: String){
        self.color = color
        if self.color == "Blue" {
            self.roll = Int (arc4random_uniform(2)+1)
        }
        else if self.color == "Red" {
            self.roll = Int (arc4random_uniform(2)+3)
        }
        else if self.color == "Green" {
            self.roll = Int (arc4random_uniform(3)+4)
        }
        else {
            self.roll = 0
        }
    }
}

class Deck {
    var cards:[Card]
    init() {
        self.cards = [Card]()
        for _ in 0..<10{
            self.cards.append(Card(color:"Blue"))
            self.cards.append(Card(color:"Red"))
            self.cards.append(Card(color:"Green"))
        }
    }
    func deal() -> Card {
        let card = self.cards[self.cards.count-1]
        self.cards.remove(at: self.cards.count-1)
        return card
    }
    func isEmpty() -> Bool {
        return self.cards.isEmpty
    }
    func shuffle() {
        for _ in 0..<self.cards.count {
            let randOne = Int (arc4random_uniform(UInt32(self.cards.count)))
            let randTwo = Int (arc4random_uniform(UInt32(self.cards.count)))
            let temp = self.cards[randOne]
            self.cards[randOne] = self.cards[randTwo]
            self.cards[randTwo] = temp
        }
    }
}

class Player {
    var name: String
    var hand: [Card]
    init(name: String) {
        self.name = name
        self.hand = [Card]()
    }
    func draw(deck: Deck) -> Card {
        let card = deck.deal()
        self.hand.append(card)
        return card
    }
    func rollDice() -> Int {
        let rand = Int (arc4random_uniform(6)+1)
        return rand
    }
    func matchingCards(color: String, roll: Int) -> Int {
        var count = 0
        for card in self.hand {
            if card.color == color && card.roll == roll{
                count+=1
            }
        }
        return count
    }
}
var deck = Deck()
deck.shuffle()
var player = Player(name: "Bobbie")
for _ in 0...20{
    player.draw(deck: deck)
}
print(player.hand)
print(player.matchingCards(color: "Red", roll: 3))
